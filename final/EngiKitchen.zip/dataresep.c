#include "dataresep.h"

char bahan[25][20] = {
    "", //0 kosong
	"Piring", //1
    "Sendok", //2
    "Garpu", //3
	"Es Krim", //4
	"Nasi", //5
	"Roti", //6
	"Spaghetti", //7
	"Pisang", //8
	"Stroberi", //9
	"Telur", //10
	"Ayam Goreng", //11
	"Patty", //12
	"Sosis", //13
	"Bolognese", //14
	"Carbonara", //15
	"Keju", //16
	"Banana Split", //17
    "Sundae", //18
    "Nasi Telur Dadar", //19
	"Nasi Ayam Goreng", //20
	"Burger", //21
	"Hot Dog", //22
	"Spaghetti Bolognese", //23
	"Spaghetti Carbonara" //24
};

char menu[9][20] = {
	"",
	"Banana Split", //17
    "Sundae", //18
    "Nasi Telur Dadar", //19
	"Nasi Ayam Goreng", //20
	"Burger", //21
	"Hot Dog", //22
	"Spaghetti Bolognese", //23
	"Spaghetti Carbonara" //24
};