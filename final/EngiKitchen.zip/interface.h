/* 	File: interface.h
	Tanggal: 25 November 2018 
	Wanul                     */
	
#ifndef INTERFACE_H
#define INTERFACE_H

void Opening ();
// Menampilkan interface opening
void Informasi ();
// Menampilkan informasi permainan
void GameOver ();
// Menampilkan interface ketika permainan berakhir
void Credit ();
// Menampilkan credit

#endif